import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const CVScreen = () => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.name}>Tayyab Tufail</Text>
        <Text style={styles.title}>React Native Developer</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionHeader}>Contact</Text>
        <Text style={styles.text}>Email: sp21-bse-032@cuiatk.edu.pk</Text>
        <Text style={styles.text}>Phone: 03455788895</Text>
        <Text style={styles.text}>Address: Attock city</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionHeader}>Education</Text>
        <Text style={styles.text}>Bachelor in Software Engineering</Text>
        <Text style={styles.text}>Comsats University Islamabad Attock Campus</Text>
        <Text style={styles.text}>Graduation Year: 2020</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionHeader}>Work Experience</Text>
        <Text style={styles.text}>Doing Some projects in Freelancing</Text>
        <Text style={styles.text}>Lead a team of developers in a project for online message sending.</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionHeader}>Skills</Text>
        <Text style={styles.text}> JavaScript</Text>
        <Text style={styles.text}> React Native</Text>
        <Text style={styles.text}> Node.js</Text>
        <Text style={styles.text}> SQL</Text>
         <Text style={styles.text}> Java</Text>
          <Text style={styles.text}> PHP</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 18,
    color: 'red',
    fontWeight: 'bold',
     

  
  },
  section: {
    marginBottom: 10,
    borderColor: 'black', 
    borderWidth: 3, 
    padding: 1, 
    backgroundColor: '#f7f7f7', 
  },
  sectionHeader: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  text: {
    fontSize: 15,
    color: 'black', 
  },
});

export default CVScreen;
