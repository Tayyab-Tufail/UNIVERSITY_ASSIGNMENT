import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StatusBar, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'; 

const LoginScreen = () => {
  return (
    <View style={styles.container}>
      {/* Status Bar */}
      <View style={styles.statusBar}>
        <View style={styles.statusIcons}>

          <Text style={styles.statusText}>TELENOR</Text>
          <Icon name="signal" size={15} color="red" />
        </View>

        <Text style={styles.statusText}>3G</Text>
        <Text style={styles.statusText}>{new Date().toLocaleTimeString()}</Text>
        <Icon name="battery-full" size={20} color="red" />

      </View>

      <View style={styles.form}>
        <TextInput
          style={styles.input}
          placeholder="Email"
        />
          <TextInput
          style={styles.input}
          placeholder="Password"
          secureTextEntry
        />

        <TouchableOpacity style={styles.loginButton}>
          <Text style={styles.loginButtonText}>LOGIN</Text>

        </TouchableOpacity>

        <View style={styles.linkContainer}>
          
          <Text style={styles.forgotPassword}>

            <Icon name="lock" size={20} color="black" /> Forget Password?
          </Text>

          <Text style={styles.createAccount}>
          <Icon name="user" size={18} color="green" />
              Create Your Account 
       
          </Text>
        
      
        </View>
      </View>

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    backgroundColor: 'pink', 
       },

  statusBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingHorizontal: 15,
  },

  statusIcons: {
    flexDirection: 'row',
    alignItems: 'center',
    color: 'red',
  },

  statusText: {
    color: 'blue',
    marginLeft: 5,
  },


  form: {
    flex: 1,
    justifyContent: 'center',
  },

  input: {
    height: 50,
    borderColor: 'green',
    borderRadius: 50, 
    borderWidth: 3,
    marginBottom: 25,
    paddingHorizontal: 15,
  },

  loginButton: {
    backgroundColor: 'orange',
    padding: 10, 
    alignItems: 'center',
    borderRadius: 50,
  },

  loginButtonText: {
    fontWeight: 'bold',
    color: 'white',
    fontSize: 30, 
  },

  linkContainer: {
    flexDirection: 'column',
    alignItems: 'center',
    marginTop: 30, 
  },

  forgotPassword: {
    flexDirection: 'row',
    alignItems: 'center',
    color: 'green',
    fontSize: 25, 
      marginTop: 10, 
  },

  createAccount: {
    flexDirection: 'row',
    alignItems: 'center',
    color: 'green',
    fontSize: 25, 
      marginTop: 10, 
  },

});


export default LoginScreen;
